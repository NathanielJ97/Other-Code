% MATLAB script for Assessment Item-1
% Task-3
clear; close all; clc;

