% MATLAB script for Assessment Item-1
% Task-2
clear; close all; clc;


