% MATLAB script for Assessment Item-1
% Task-4
clear; close all; clc;

